Instructions for setup and use of these examples can be found at:
http://links.sonatype.com/products/nexus/oss/docs-jetty